<?php

$databaseHost = 'localhost';
$databaseName = 'wirelesspatient';
$databaseUsername = 'root';
$databasePassword = 'naruto';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
 
?>
